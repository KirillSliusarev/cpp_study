#include <iostream> //input output stream
using namespace std; // namespace standart
int main() // main func
{
    setlocale(LC_ALL, ""); // setting up lacale
    cout << "первая \\строка\n"; // first output
    cout << "\"вторая строка\""; // second output
}